### Genaration

This tab can be used for generating new data from learned Markov models.

Just fill in the blanks and generate trajectories for as many patients as you wish.
NB! You'll have to generate the Markov model (discrete or continuous) before creating synthetic trajectories.

When selecting **Generate cost per state from observed data?** the cost of state will also be generated for trajectories. The costs' distribution parameters are retrieved from the data.

**Observed vs generated**
Inclusion statistics for comparing the generated data with observed data.

**LogRanks tests**
LogRank tests shown for transitions between states. We compare observed and generated data for each possible transition between states.



