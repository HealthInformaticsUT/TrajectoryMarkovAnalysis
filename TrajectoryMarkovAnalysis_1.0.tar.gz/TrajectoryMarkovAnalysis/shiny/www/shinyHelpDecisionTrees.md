### Decision Trees

Build a decision tree from specified layers. 

**Probability in target cohort** Shows the probability of the transitsion occurring in the data
**Probability on layer level** Shows the probability of the transitsion occurring in the data divided by the sum of the options on the layers



