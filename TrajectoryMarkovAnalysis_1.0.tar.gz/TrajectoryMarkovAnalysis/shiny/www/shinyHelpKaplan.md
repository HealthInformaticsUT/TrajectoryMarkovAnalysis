### Kaplan-Meier plots

**Usage** 

Choose the transitsion you want to visualise with Kaplan-Meier plots.

You can also add age intervals and compare them between each other.



