
## Import
### Usage

This tab is used for data import.

Choose a .csv file consisting of patients' treatment trajectories and upload it.