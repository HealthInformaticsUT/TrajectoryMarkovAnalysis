library(testthat)
library(Cohort2Trajectory)

test_check("Cohort2Trajectory")
