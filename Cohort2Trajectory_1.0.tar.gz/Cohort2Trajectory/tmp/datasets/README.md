This is a directory where all generated files will be held
